import 'package:acevedo0425/models/product_model.dart';

List<ProductModel> products = [
  ProductModel(
      img: "assets/descarga.png",
      title: "Ipohne 1",
      description: "Burgers not"),
  ProductModel(
      img: "assets/fon.jpg", title: "Ipohne 2", description: "Burgers not"),
  ProductModel(
      img: "assets/burger.png", title: "Iphone 3", description: "Burgers not"),
];
