class ProductModel {
  final String img;
  final String title;
  final String description;

  ProductModel(
      {required this.img, required this.title, required this.description});
}
